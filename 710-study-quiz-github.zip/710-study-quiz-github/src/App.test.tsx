import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it } from 'vitest'
import type { QuizQuestion } from './types'
import App from './App'
import { questions } from './data/questions'

const sample: QuizQuestion[] = [{
  id: 'sample', pdfPage: 1, prompt: '正しい選択肢は？',
  choices: [{ id: 'a', text: '正解' }, { id: 'b', text: '誤答B' }, { id: 'c', text: '誤答C' }, { id: 'd', text: '誤答D' }],
  correctChoiceId: 'a', explanation: '基本問題の解説',
  followUp: {
    prompt: '理由は？',
    choices: [{ id: 'fa', text: '正しい理由' }, { id: 'fb', text: '誤り1' }, { id: 'fc', text: '誤り2' }, { id: 'fd', text: '誤り3' }],
    correctChoiceId: 'fa', explanation: '理由の解説',
  },
}]

describe('study UI', () => {
  it('runs primary and follow-up questions through to the result', async () => {
    const user = userEvent.setup()
    render(<App quizQuestions={sample} random={() => 0.5} storage={localStorage} />)
    await user.click(screen.getByRole('button', { name: '学習開始' }))
    await user.click(screen.getByRole('button', { name: '正解' }))
    expect(screen.getByText('正解です')).toBeInTheDocument()
    expect(screen.queryByText('基本問題の解説')).not.toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: '正しい理由' }))
    expect(screen.getByText('理由の解説')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: '結果を見る' }))
    expect(screen.getByText('100点')).toBeInTheDocument()
  })

  it('skips follow-up after a wrong primary answer', async () => {
    const user = userEvent.setup()
    render(<App quizQuestions={sample} random={() => 0.5} storage={localStorage} />)
    await user.click(screen.getByRole('button', { name: '学習開始' }))
    await user.click(screen.getByRole('button', { name: '誤答B' }))
    expect(screen.queryByText('理由は？')).not.toBeInTheDocument()
    expect(screen.getByText('基本問題の解説')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '結果を見る' })).toBeInTheDocument()
  })

  it('shows a wrongly answered follow-up in the review list', async () => {
    const user = userEvent.setup()
    render(<App quizQuestions={sample} random={() => 0.5} storage={localStorage} />)
    await user.click(screen.getByRole('button', { name: '学習開始' }))
    await user.click(screen.getByRole('button', { name: '正解' }))
    await user.click(screen.getByRole('button', { name: '誤り1' }))
    await user.click(screen.getByRole('button', { name: '結果を見る' }))
    expect(screen.getByText('理由は？')).toBeInTheDocument()
    expect(screen.getByText('理由の解説')).toBeInTheDocument()
  })

  it('asks why glutaral cannot be used on hands after question 33', async () => {
    const user = userEvent.setup()
    const question33 = questions.find((question) => question.pdfPage === 33)!
    render(<App quizQuestions={[question33]} random={() => 0.5} storage={localStorage} />)
    await user.click(screen.getByRole('button', { name: '学習開始' }))
    await user.click(screen.getByRole('button', { name: '手指皮膚―グルタラール' }))
    expect(screen.getByRole('heading', { name: 'グルタラールを手指皮膚に使用できない主な理由はどれか。' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '毒性が強い' })).toBeInTheDocument()
  })
})
