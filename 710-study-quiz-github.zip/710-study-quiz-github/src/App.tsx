import { useState } from 'react'
import { questions } from './data/questions'
import { advance, answerFollowUp, answerPrimary, calculateResult, createSession, type QuizSession } from './domain/quizEngine'
import { clearSession, loadSession, saveSession } from './storage/sessionStorage'
import type { Choice, QuizQuestion } from './types'

interface Props {
  quizQuestions?: QuizQuestion[]
  random?: () => number
  storage?: Storage
}

const orderedChoices = (choices: Choice[], order: string[]) => order.map((id) => choices.find((choice) => choice.id === id)!).filter(Boolean)

export default function App({ quizQuestions = questions, random = Math.random, storage = window.localStorage }: Props) {
  const [saved, setSaved] = useState<QuizSession | null>(() => loadSession(storage, quizQuestions))
  const [session, setSession] = useState<QuizSession | null>(null)

  const update = (next: QuizSession) => { setSession(next); setSaved(next); saveSession(storage, next) }
  const start = () => update(createSession(quizQuestions, random))
  const reset = () => { clearSession(storage); setSaved(null); setSession(null) }

  if (!session) return (
    <main className="shell start-screen">
      <section className="card hero">
        <span className="eyebrow">60問・ランダム学習</span>
        <h1>710演習問題<br />学習クイズ</h1>
        <p>問題と選択肢を毎回シャッフル。正解後は、理由を確かめる追加問題にも挑戦します。</p>
        <button className="primary" onClick={start}>学習開始</button>
        {saved && <button className="secondary" onClick={() => setSession(saved)}>続きから</button>}
      </section>
    </main>
  )

  if (session.screen === 'result') {
    const result = calculateResult(session)
    const wrong = session.items.filter((item) => item.primaryCorrect === false || item.followUpCorrect === false)
    return (
      <main className="shell">
        <section className="card result-card">
          <span className="eyebrow">学習完了</span>
          <h1>{result.percent}点</h1>
          <div className="score-grid">
            <div><strong>{result.primaryCorrect}</strong><span>第1問 正解</span></div>
            <div><strong>{result.followUpCorrect}</strong><span>理由問題 正解</span></div>
            <div><strong>{result.correct}/{result.answered}</strong><span>総合</span></div>
          </div>
          <button className="primary" onClick={start}>もう一度ランダムに挑戦</button>
          <button className="secondary" onClick={reset}>履歴を消して終了</button>
        </section>
        {wrong.length > 0 && <section className="review"><h2>復習する問題</h2>{wrong.map((item) => {
          const question = quizQuestions.find((entry) => entry.id === item.questionId)!
          return <article className="card review-item" key={item.questionId}>
            <span>PDF {question.pdfPage}ページ</span>
            {item.primaryCorrect === false && <><h3>{question.prompt}</h3><p>{question.explanation}</p></>}
            {item.followUpCorrect === false && question.followUp && <><h3>{question.followUp.prompt}</h3><p>{question.followUp.explanation}</p></>}
          </article>
        })}</section>}
      </main>
    )
  }

  const item = session.items[session.currentIndex]
  const question = quizQuestions.find((entry) => entry.id === item.questionId)!
  const primaryAnswered = item.primaryChoiceId !== undefined
  const followAnswered = item.followUpChoiceId !== undefined
  const canAdvance = primaryAnswered && (!item.needsFollowUp || followAnswered)
  const nextLabel = session.currentIndex === session.items.length - 1 ? '結果を見る' : '次の問題'

  const choiceClass = (id: string, answerId: string, selectedId?: string) => {
    if (!selectedId) return 'choice'
    if (id === answerId) return 'choice correct'
    if (id === selectedId) return 'choice wrong'
    return 'choice muted'
  }

  return (
    <main className="shell">
      <header className="progress-header">
        <div><span className="eyebrow">進捗</span><strong>{session.currentIndex + 1} / {session.items.length}</strong></div>
        <div className="progress"><span style={{ width: `${((session.currentIndex + 1) / session.items.length) * 100}%` }} /></div>
      </header>
      <section className="card question-card">
        <span className="page-label">PDF {question.pdfPage}ページ</span>
        <h1>{question.prompt}</h1>
        <div className="choices">{orderedChoices(question.choices, item.choiceOrder).map((choice) => (
          <button key={choice.id} className={choiceClass(choice.id, question.correctChoiceId, item.primaryChoiceId)} disabled={primaryAnswered} onClick={() => update(answerPrimary(session, choice.id, quizQuestions))}>{choice.text}</button>
        ))}</div>
        {primaryAnswered && <div className={`feedback ${item.primaryCorrect ? 'ok' : 'ng'}`} role="status">
          <h2>{item.primaryCorrect ? '正解です' : '不正解です'}</h2>
          {!item.needsFollowUp && <p>{question.explanation}</p>}
        </div>}
      </section>

      {item.needsFollowUp && question.followUp && <section className="card follow-card">
        <span className="eyebrow">理解チェック</span><h2>{question.followUp.prompt}</h2>
        <div className="choices">{orderedChoices(question.followUp.choices, item.followUpChoiceOrder ?? []).map((choice) => (
          <button key={choice.id} className={choiceClass(choice.id, question.followUp!.correctChoiceId, item.followUpChoiceId)} disabled={followAnswered} onClick={() => update(answerFollowUp(session, choice.id, quizQuestions))}>{choice.text}</button>
        ))}</div>
        {followAnswered && <div className={`feedback ${item.followUpCorrect ? 'ok' : 'ng'}`}><h2>{item.followUpCorrect ? '正解です' : '不正解です'}</h2><p>{question.followUp.explanation}</p></div>}
      </section>}
      {canAdvance && <button className="primary next" onClick={() => update(advance(session))}>{nextLabel}</button>}
    </main>
  )
}
