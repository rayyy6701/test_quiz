import { describe, expect, it } from 'vitest'
import { questions } from './questions'

describe('PDF question data', () => {
  it('contains exactly one question for every PDF page', () => {
    expect(questions).toHaveLength(60)
    expect(questions.map((q) => q.pdfPage).sort((a, b) => a - b)).toEqual(
      Array.from({ length: 60 }, (_, index) => index + 1),
    )
  })

  it('contains four choices, a valid answer, and an explanation', () => {
    for (const question of questions) {
      expect(question.prompt.trim()).not.toBe('')
      expect(question.choices).toHaveLength(4)
      expect(new Set(question.choices.map((choice) => choice.id)).size).toBe(4)
      expect(question.choices.some((choice) => choice.id === question.correctChoiceId)).toBe(true)
      expect(question.explanation.trim()).not.toBe('')
    }
  })

  it('keeps every follow-up as a complete four-choice question', () => {
    expect(questions.filter((question) => question.followUp).length).toBeGreaterThanOrEqual(30)
    for (const { followUp } of questions) {
      if (!followUp) continue
      expect(followUp.choices).toHaveLength(4)
      expect(followUp.choices.some((choice) => choice.id === followUp.correctChoiceId)).toBe(true)
      expect(followUp.explanation.trim()).not.toBe('')
    }
  })

  it('uses deeper follow-ups instead of repeating the primary answer', () => {
    const expected = new Map<number, [string, string]>([
      [10, ['予防接種が第1次予防に分類される理由はどれか。', '疾病の発生を事前に防ぐため']],
      [17, ['動物性脂肪の過剰摂取を控える主な理由はどれか。', '動脈硬化などのリスクを高めるため']],
      [19, ['無症状病原体保有者が感染源になりうる理由はどれか。', '症状がなくても病原体を保有しているため']],
      [21, ['第1次予防で重視される取り組みはどれか。', '生活習慣を改善して発症を防ぐ']],
      [26, ['生活習慣病の予防を幼少期から始める理由はどれか。', '生活習慣は幼少期から形成されるため']],
      [27, ['公衆衛生行政の4本立てで、3本に加えて必要な分野はどれか。', '環境保健行政']],
      [29, ['水道行政が環境省へ移管された時期はどれか。', '2024年4月']],
      [30, ['75歳以上の高齢者区分はどれか。', '後期高齢者']],
      [33, ['グルタラールを手指皮膚に使用できない主な理由はどれか。', '毒性が強い']],
      [56, ['生活習慣病予防を早期に始めるべき理由はどれか。', '生活習慣は幼少期から形成されるため']],
      [58, ['結核が生活習慣病に含まれない理由はどれか。', '結核菌による感染症だから']],
      [60, ['一般細菌の水質基準はどれか。', '1mLで集落数100以下']],
    ])

    for (const [page, [prompt, answer]] of expected) {
      const followUp = questions.find((question) => question.pdfPage === page)?.followUp
      expect(followUp?.prompt).toBe(prompt)
      expect(followUp?.choices.find((choice) => choice.id === followUp.correctChoiceId)?.text).toBe(answer)
    }
  })
})
