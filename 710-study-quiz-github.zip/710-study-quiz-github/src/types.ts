export interface Choice { id: string; text: string }

export interface FollowUpQuestion {
  prompt: string
  choices: Choice[]
  correctChoiceId: string
  explanation: string
}

export interface QuizQuestion {
  id: string
  pdfPage: number
  prompt: string
  choices: Choice[]
  correctChoiceId: string
  explanation: string
  followUp?: FollowUpQuestion
}
