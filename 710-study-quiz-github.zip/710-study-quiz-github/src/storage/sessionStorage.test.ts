import { describe, expect, it } from 'vitest'
import { questions } from '../data/questions'
import { createSession } from '../domain/quizEngine'
import { clearSession, loadSession, saveSession } from './sessionStorage'

class MemoryStorage implements Storage {
  private data = new Map<string, string>()
  get length() { return this.data.size }
  clear() { this.data.clear() }
  getItem(key: string) { return this.data.get(key) ?? null }
  key(index: number) { return [...this.data.keys()][index] ?? null }
  removeItem(key: string) { this.data.delete(key) }
  setItem(key: string, value: string) { this.data.set(key, value) }
}

describe('session storage', () => {
  it('saves and restores a valid session', () => {
    const storage = new MemoryStorage()
    const session = createSession(questions, () => 0.5)
    expect(saveSession(storage, session)).toBe(true)
    expect(loadSession(storage, questions)).toEqual(session)
  })

  it('rejects invalid JSON and unknown question ids', () => {
    const storage = new MemoryStorage()
    storage.setItem('710-study-session', '{broken')
    expect(loadSession(storage, questions)).toBeNull()
    storage.setItem('710-study-session', JSON.stringify({ version: 1, screen: 'quiz', currentIndex: 0, items: [{ questionId: 'unknown', choiceOrder: [] }] }))
    expect(loadSession(storage, questions)).toBeNull()
  })

  it('rejects truncated sessions and duplicate choice order entries', () => {
    const storage = new MemoryStorage()
    const session = createSession(questions, () => 0.5)
    storage.setItem('710-study-session', JSON.stringify({ ...session, items: session.items.slice(0, 1) }))
    expect(loadSession(storage, questions)).toBeNull()
    session.items[0].choiceOrder = Array(4).fill(session.items[0].choiceOrder[0])
    storage.setItem('710-study-session', JSON.stringify(session))
    expect(loadSession(storage, questions)).toBeNull()
  })

  it('survives storage write errors and can clear data', () => {
    const storage = new MemoryStorage()
    const session = createSession(questions, () => 0.5)
    const failing = { ...storage, setItem: () => { throw new Error('blocked') } } as unknown as Storage
    expect(saveSession(failing, session)).toBe(false)
    saveSession(storage, session)
    clearSession(storage)
    expect(loadSession(storage, questions)).toBeNull()
  })
})
