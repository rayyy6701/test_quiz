import type { QuizQuestion } from '../types'
import type { QuizSession, SessionItem } from '../domain/quizEngine'

const KEY = '710-study-session'

const isStringArray = (value: unknown): value is string[] =>
  Array.isArray(value) && value.every((entry) => typeof entry === 'string')

const isItem = (value: unknown, questions: QuizQuestion[]): value is SessionItem => {
  if (!value || typeof value !== 'object') return false
  const item = value as Partial<SessionItem>
  const question = questions.find((candidate) => candidate.id === item.questionId)
  if (!question || !isStringArray(item.choiceOrder) || item.choiceOrder.length !== 4 || new Set(item.choiceOrder).size !== 4) return false
  if (!item.choiceOrder.every((id) => question.choices.some((choice) => choice.id === id))) return false
  if (question.followUp && (!isStringArray(item.followUpChoiceOrder) || item.followUpChoiceOrder.length !== 4 || new Set(item.followUpChoiceOrder).size !== 4)) return false
  if (question.followUp && !item.followUpChoiceOrder!.every((id) => question.followUp!.choices.some((choice) => choice.id === id))) return false
  if (!question.followUp && item.followUpChoiceOrder !== undefined) return false
  if (item.primaryChoiceId === undefined) return item.primaryCorrect === undefined && item.needsFollowUp === undefined && item.followUpChoiceId === undefined && item.followUpCorrect === undefined
  if (!question.choices.some((choice) => choice.id === item.primaryChoiceId)) return false
  const primaryCorrect = item.primaryChoiceId === question.correctChoiceId
  const needsFollowUp = primaryCorrect && Boolean(question.followUp)
  if (item.primaryCorrect !== primaryCorrect || item.needsFollowUp !== needsFollowUp) return false
  if (!needsFollowUp) return item.followUpChoiceId === undefined && item.followUpCorrect === undefined
  if (item.followUpChoiceId === undefined) return item.followUpCorrect === undefined
  if (!question.followUp!.choices.some((choice) => choice.id === item.followUpChoiceId)) return false
  if (item.followUpCorrect !== (item.followUpChoiceId === question.followUp!.correctChoiceId)) return false
  return true
}

const isSession = (value: unknown, questions: QuizQuestion[]): value is QuizSession => {
  if (!value || typeof value !== 'object') return false
  const session = value as Partial<QuizSession>
  return session.version === 1
    && (session.screen === 'quiz' || session.screen === 'result')
    && Number.isInteger(session.currentIndex)
    && Array.isArray(session.items)
    && session.items.length === questions.length
    && new Set(session.items.map((item) => (item as SessionItem).questionId)).size === questions.length
    && session.currentIndex! >= 0
    && session.currentIndex! < session.items.length
    && session.items.every((item) => isItem(item, questions))
}

export const saveSession = (storage: Storage, session: QuizSession): boolean => {
  try {
    storage.setItem(KEY, JSON.stringify(session))
    return true
  } catch {
    return false
  }
}

export const loadSession = (storage: Storage, questions: QuizQuestion[]): QuizSession | null => {
  try {
    const raw = storage.getItem(KEY)
    if (!raw) return null
    const parsed: unknown = JSON.parse(raw)
    return isSession(parsed, questions) ? parsed : null
  } catch {
    return null
  }
}

export const clearSession = (storage: Storage): void => {
  try { storage.removeItem(KEY) } catch { /* 学習は保存なしで継続する */ }
}
