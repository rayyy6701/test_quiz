import { describe, expect, it } from 'vitest'
import { questions } from '../data/questions'
import { advance, answerFollowUp, answerPrimary, calculateResult, createSession } from './quizEngine'

describe('quiz engine', () => {
  it('creates a session with every question and every choice exactly once', () => {
    const session = createSession(questions, () => 0.25)
    expect(session.items).toHaveLength(60)
    expect(new Set(session.items.map((item) => item.questionId)).size).toBe(60)
    for (const item of session.items) expect(new Set(item.choiceOrder).size).toBe(4)
  })

  it('scores by choice id and ignores a second primary answer', () => {
    const session = createSession(questions, () => 0.5)
    const question = questions.find((q) => q.id === session.items[0].questionId)!
    const answered = answerPrimary(session, question.correctChoiceId, questions)
    expect(answered.items[0].primaryCorrect).toBe(true)
    expect(answerPrimary(answered, 'missing', questions)).toEqual(answered)
  })

  it('offers follow-up only after a correct primary answer', () => {
    const source = questions.find((q) => q.followUp)!
    const session = createSession([source], () => 0.5)
    const wrong = source.choices.find((choice) => choice.id !== source.correctChoiceId)!.id
    expect(answerPrimary(session, wrong, [source]).items[0].needsFollowUp).toBe(false)
    expect(answerPrimary(session, source.correctChoiceId, [source]).items[0].needsFollowUp).toBe(true)
  })

  it('records a follow-up answer and calculates the combined score', () => {
    const source = questions.find((q) => q.followUp)!
    let session = createSession([source], () => 0.5)
    session = answerPrimary(session, source.correctChoiceId, [source])
    session = answerFollowUp(session, source.followUp!.correctChoiceId, [source])
    expect(calculateResult(session)).toMatchObject({ primaryCorrect: 1, followUpCorrect: 1, answered: 2, correct: 2, percent: 100 })
    expect(advance(session).screen).toBe('result')
  })
})
