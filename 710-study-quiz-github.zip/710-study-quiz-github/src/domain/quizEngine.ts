import type { QuizQuestion } from '../types'

export type QuizScreen = 'quiz' | 'result'

export interface SessionItem {
  questionId: string
  choiceOrder: string[]
  followUpChoiceOrder?: string[]
  primaryChoiceId?: string
  primaryCorrect?: boolean
  needsFollowUp?: boolean
  followUpChoiceId?: string
  followUpCorrect?: boolean
}

export interface QuizSession {
  version: 1
  screen: QuizScreen
  currentIndex: number
  items: SessionItem[]
}

export const shuffleIds = <T>(items: readonly T[], random: () => number = Math.random): T[] => {
  const copy = [...items]
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const target = Math.floor(random() * (index + 1))
    ;[copy[index], copy[target]] = [copy[target], copy[index]]
  }
  return copy
}

export const createSession = (questions: QuizQuestion[], random: () => number = Math.random): QuizSession => ({
  version: 1,
  screen: 'quiz',
  currentIndex: 0,
  items: shuffleIds(questions, random).map((question) => ({
    questionId: question.id,
    choiceOrder: shuffleIds(question.choices.map((choice) => choice.id), random),
    followUpChoiceOrder: question.followUp
      ? shuffleIds(question.followUp.choices.map((choice) => choice.id), random)
      : undefined,
  })),
})

const current = (session: QuizSession) => session.items[session.currentIndex]

export const answerPrimary = (session: QuizSession, choiceId: string, questions: QuizQuestion[]): QuizSession => {
  const item = current(session)
  if (!item || item.primaryChoiceId !== undefined) return session
  const question = questions.find((candidate) => candidate.id === item.questionId)
  if (!question || !question.choices.some((choice) => choice.id === choiceId)) return session
  const primaryCorrect = choiceId === question.correctChoiceId
  const updated = { ...item, primaryChoiceId: choiceId, primaryCorrect, needsFollowUp: primaryCorrect && Boolean(question.followUp) }
  return { ...session, items: session.items.map((entry, index) => index === session.currentIndex ? updated : entry) }
}

export const answerFollowUp = (session: QuizSession, choiceId: string, questions: QuizQuestion[]): QuizSession => {
  const item = current(session)
  if (!item?.needsFollowUp || item.followUpChoiceId !== undefined) return session
  const question = questions.find((candidate) => candidate.id === item.questionId)
  if (!question?.followUp?.choices.some((choice) => choice.id === choiceId)) return session
  const updated = { ...item, followUpChoiceId: choiceId, followUpCorrect: choiceId === question.followUp.correctChoiceId }
  return { ...session, items: session.items.map((entry, index) => index === session.currentIndex ? updated : entry) }
}

export const advance = (session: QuizSession): QuizSession => {
  const item = current(session)
  const canAdvance = item?.primaryChoiceId && (!item.needsFollowUp || item.followUpChoiceId)
  if (!canAdvance) return session
  if (session.currentIndex === session.items.length - 1) return { ...session, screen: 'result' }
  return { ...session, currentIndex: session.currentIndex + 1 }
}

export const calculateResult = (session: QuizSession) => {
  const primaryCorrect = session.items.filter((item) => item.primaryCorrect).length
  const followUpCorrect = session.items.filter((item) => item.followUpCorrect).length
  const primaryAnswered = session.items.filter((item) => item.primaryChoiceId !== undefined).length
  const followUpAnswered = session.items.filter((item) => item.followUpChoiceId !== undefined).length
  const answered = primaryAnswered + followUpAnswered
  const correct = primaryCorrect + followUpCorrect
  return { primaryCorrect, followUpCorrect, answered, correct, percent: answered ? Math.round((correct / answered) * 100) : 0 }
}
