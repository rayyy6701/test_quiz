from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import pdfplumber


PROJECT = Path(__file__).resolve().parents[1]
PDF_PATH = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else PROJECT / "source.pdf"
PAGE_DIR = PROJECT / "work" / "pdf-pages"
OUTPUT = PROJECT / "work" / "extracted-pages.json"
POPPLER_BIN = shutil.which("pdftoppm")


def color_name(value: object) -> str:
    if not isinstance(value, tuple):
        return "other"
    if len(value) == 1:
        return "white" if value[0] > 0.9 else "black"
    red, green, blue = value[:3]
    if red > 0.85 and green < 0.2 and blue < 0.2:
        return "red"
    if green > red * 1.3 and green > blue * 1.1:
        return "green"
    return "black"


def normalize_text(text: str) -> str:
    text = text.replace("\u3000", " ")
    return re.sub(r"[ \t]+", " ", text).strip()


def extract_page(page: pdfplumber.page.Page, page_number: int) -> dict[str, object]:
    words = page.extract_words(extra_attrs=["non_stroking_color"], use_text_flow=True)
    groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    for word in words:
        groups[color_name(word.get("non_stroking_color"))].append({
            "text": normalize_text(str(word["text"])),
            "x0": round(float(word["x0"]), 2),
            "top": round(float(word["top"]), 2),
            "x1": round(float(word["x1"]), 2),
            "bottom": round(float(word["bottom"]), 2),
        })
    return {
        "page": page_number,
        "width": page.width,
        "height": page.height,
        "fullText": normalize_text(page.extract_text() or ""),
        "colors": groups,
    }


def main() -> None:
    if POPPLER_BIN is None:
        raise SystemExit("pdftoppm was not found. Install Poppler and add it to PATH.")
    if not PDF_PATH.is_file():
        raise SystemExit(f"PDF was not found: {PDF_PATH}")
    PAGE_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([POPPLER_BIN, "-png", "-r", "110", str(PDF_PATH), str(PAGE_DIR / "page")], check=True)
    with pdfplumber.open(PDF_PATH) as pdf:
        pages = [extract_page(page, index + 1) for index, page in enumerate(pdf.pages)]
    OUTPUT.write_text(json.dumps(pages, ensure_ascii=False, indent=2), encoding="utf-8")
    green_pages = sum(bool(page["colors"].get("green")) for page in pages)
    red_pages = sum(bool(page["colors"].get("red")) for page in pages)
    print(f"pages={len(pages)} green_pages={green_pages} red_pages={red_pages}")
    if len(pages) != 60 or green_pages != 60 or red_pages != 60:
        raise SystemExit("PDF audit failed: expected green and red content on all 60 pages")


if __name__ == "__main__":
    main()
